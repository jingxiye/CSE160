let g_legsAngle = 0;
let g_secondJointAngle = 0;
let g_tailAngleX = 15;
let g_tailAngleY = 0;
let x_val = 0;
let y_val = 0;
let g_headTransform = 0;
let g_bodyTransform = 0;
let g_bodyRotate = 0;

